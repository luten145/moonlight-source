package com.limelight.ui;

public interface GameGestures {
    void toggleKeyboard();
}
